# Dynamic Toggle with [type=radio] + :has()

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/vEEZxOM](https://codepen.io/jh3y/pen/vEEZxOM).


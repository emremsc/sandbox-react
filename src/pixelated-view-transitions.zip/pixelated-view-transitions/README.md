# Pixelated View Transitions

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/QwLdaQX](https://codepen.io/jh3y/pen/QwLdaQX).


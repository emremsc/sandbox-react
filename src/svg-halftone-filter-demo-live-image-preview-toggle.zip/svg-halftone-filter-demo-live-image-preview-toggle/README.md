# SVG Halftone Filter Demo: Live Image Preview & Toggle

A Pen created on CodePen.

Original URL: [https://codepen.io/rodzyk/pen/qEExxGJ](https://codepen.io/rodzyk/pen/qEExxGJ).

Explore how halftone effects can be applied using pure SVG filters — no CSS tricks or raster effects. Upload your own image or paste a URL, then switch between two scalable vector halftone styles (half-tone and half-tone-hd). Great for experimenting with non-destructive, resolution-independent image filtering in real time.
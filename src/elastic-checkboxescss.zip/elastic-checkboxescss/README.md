# Elastic Checkboxes - CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/josetxu/pen/raOgrKx](https://codepen.io/josetxu/pen/raOgrKx).

Inspired by <strong>Chris' Corner</strong> of this week's <strong>CodePen Spark</strong>.  

Some really cool checkboxes based on <strong>Enzo Manuel Mangano</strong>'s article <a href="https://reactiive.io/articles/checkbox-interactions">"Checkbox Interactions - The Beauty of Layout Animations."</a>  

Don't get the weekly CodePen Spark newsletter?  
<a href="https://codepen.io/settings/notifications">Subscribe!</a> It's always very interesting.
# Gradients from Nature

A Pen created on CodePen.

Original URL: [https://codepen.io/billyysea/pen/kvjNBj](https://codepen.io/billyysea/pen/kvjNBj).

Twenty-four five tone gradients sampled from California skies. Penned by Anastasia Tumanova
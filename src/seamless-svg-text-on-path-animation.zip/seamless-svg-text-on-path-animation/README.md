# Seamless SVG text on path animation

A Pen created on CodePen.

Original URL: [https://codepen.io/ccrch/pen/qEddXma](https://codepen.io/ccrch/pen/qEddXma).

Small trick with two text paths animating simultaneously to create a perfect loop. Can be used for any type of a closed path, not only ellipse. Easy to set up & control text content & properties of the animation.

Effect created for Háreyðing  - https://hareyding.is/

Made with <❤/> at Vettvangur - https://vettvangur.is/
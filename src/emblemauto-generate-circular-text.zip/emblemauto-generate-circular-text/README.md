# Emblem - Auto generate circular text

A Pen created on CodePen.

Original URL: [https://codepen.io/georgehastings/pen/aZexaz](https://codepen.io/georgehastings/pen/aZexaz).

Tiny JS lib to generate a text emblem 
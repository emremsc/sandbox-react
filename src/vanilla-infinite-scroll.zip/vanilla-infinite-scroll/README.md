# Vanilla Infinite Scroll 🧑‍🍳

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/empxNaB](https://codepen.io/jh3y/pen/empxNaB).


// circular list using 3-block clones.
// - Clones are hidden from assistive tech (aria-hidden + inert).
// - No node reshuffling during scroll; only rare ±B scrollTop jumps.
// - Exposes --loop-turns (continuous) and --loop-progress (0..1).

(function initAccessibleInfiniteList() {
  const controller = document.querySelector('.controller');
  const list = controller?.querySelector('.loop');
  if (!controller || !list) return;

  // 1) Read originals (strip a manual trailing duplicate if present)
  let originalsEls = Array.from(list.children);
  if (originalsEls.length === 0) return;
  if (
    originalsEls.length > 1 &&
    originalsEls[0].outerHTML === originalsEls[originalsEls.length - 1].outerHTML
  ) {
    list.removeChild(list.lastElementChild);
    originalsEls = Array.from(list.children);
  }

  // Assign stable data-index to originals (for focus redirection)
  originalsEls.forEach((li, i) => li.dataset.idx = String(i));

  // 2) Clone before/after. Clones are hidden from AT and inert.
  const makeClone = (el, cls) => {
    const c = el.cloneNode(true);
    c.classList.add('clone', cls);
    c.setAttribute('aria-hidden', 'true');
    c.setAttribute('inert', '');
    // Remove from tab order just in case
    c.tabIndex = -1;
    // Also mark each item’s data-idx so we can map focus if needed
    c.dataset.idx = el.dataset.idx;
    return c;
  };

  const before = originalsEls.map(el => makeClone(el, 'clone-before'));
  const after  = originalsEls.map(el => makeClone(el, 'clone-after'));

  list.prepend(...before);
  list.append(...after);

  // 3) Measure one block height (B) from the middle block to include real sizes
  const all = Array.from(list.children);
  const count = originalsEls.length;
  const middleStart = count;
  const middleEnd = count * 2;
  const middleBlockEls = all.slice(middleStart, middleEnd);

  const blockHeight = middleBlockEls.reduce((h, li) => h + li.offsetHeight, 0);

  // 4) Start in the middle block so we can jump ±B later
  controller.scrollTop = blockHeight;

  // 5) Motion vars: continuous unwrapped distance (ignore ±B recenters)
  const mod = (n, m) => ((n % m) + m) % m;
  let lastRaw = controller.scrollTop;
  let unwrapped = 0;
  let jumping = false;
  let rafScheduled = false;

  function updateMotionVars() {
    const B = blockHeight;
    const V = controller.clientHeight;
    const S = Math.max(1, B - V);
    const turns = unwrapped / S;
    const progress01 = mod(unwrapped, S) / S;
    const r = document.documentElement.style;
    r.setProperty('--loop-turns', String(turns));
    r.setProperty('--loop-progress', String(progress01));
  }

  // 6) Keep scroll anchored in middle third
  const lower = blockHeight * 0.25;
  const upper = blockHeight * 1.75;

  function normalizeIfNeeded() {
    if (jumping) return;
    const t = controller.scrollTop;
    if (t < lower) {
      jumping = true;
      controller.classList.add('no-snap');
      controller.scrollTop = t + blockHeight;
      requestAnimationFrame(() => controller.classList.remove('no-snap'));
      jumping = false;
    } else if (t > upper) {
      jumping = true;
      controller.classList.add('no-snap');
      controller.scrollTop = t - blockHeight;
      requestAnimationFrame(() => controller.classList.remove('no-snap'));
      jumping = false;
    }
  }

  // 7) Scroll loop (throttled)
  controller.addEventListener('scroll', () => {
    if (rafScheduled) return;
    rafScheduled = true;
    requestAnimationFrame(() => {
      rafScheduled = false;

      normalizeIfNeeded();

      const raw = controller.scrollTop;
      let delta = raw - lastRaw;
      // Ignore synthetic big jumps from normalization
      if (Math.abs(delta) > blockHeight * 0.6) delta = 0;

      unwrapped += delta;
      lastRaw = raw;

      updateMotionVars();
    });
  }, { passive: true });

  // 8) Keyboard focus redirection (clones → matching middle item)
  // Ensures tab/shift+tab and programmatic focus stay within the middle copy.
  list.addEventListener('focusin', (e) => {
    const target = e.target;
    if (!(target instanceof HTMLElement)) return;
    const li = target.closest('li');
    if (!li) return;

    if (li.classList.contains('clone')) {
      // Map to corresponding middle-block element by data-idx
      const idx = li.dataset.idx;
      const middleMatch = list.querySelector(`.loop > li:not(.clone)[data-idx="${idx}"]`);
      if (middleMatch instanceof HTMLElement) {
        // Move focus to the real item; try to place caret appropriately if needed
        middleMatch.focus({ preventScroll: true });
      }
    }
  });

  // 9) Initialize CSS vars once
  updateMotionVars();

  // 10) Optional: respond to container resizes (fonts/viewport changes)
  // If you expect frequent resizes, you can recalc thresholds & reset lastRaw.
  const ro = new ResizeObserver(() => {
    // Keep the same relative position: center again at ~middle
    controller.classList.add('no-snap');
    controller.scrollTop = blockHeight + mod(controller.scrollTop, blockHeight);
    requestAnimationFrame(() => controller.classList.remove('no-snap'));
    lastRaw = controller.scrollTop;
    updateMotionVars();
  });
  ro.observe(controller);
})();
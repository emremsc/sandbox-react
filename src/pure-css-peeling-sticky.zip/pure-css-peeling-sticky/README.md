# Pure CSS Peeling Sticky

A Pen created on CodePen.

Original URL: [https://codepen.io/patrickkunka/pen/DeZQXw](https://codepen.io/patrickkunka/pen/DeZQXw).

Another experiment into CSS circles I built for a feature on the upcoming www.barrelny.com redesign.

The sticky is made from two seperate circles (front and back), which are moved and masked inversely on :hover (by the circle wrapper elements). A rotation is also applied to mimic realistic motion. Gradients are applied to the front and back to give the illusion of depth.
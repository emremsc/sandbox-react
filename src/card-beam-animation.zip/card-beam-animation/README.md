# Card Beam Animation

A Pen created on CodePen.

Original URL: [https://codepen.io/blacklead-studio/pen/xbwaqxE](https://codepen.io/blacklead-studio/pen/xbwaqxE).

An experimental animation where cards slide through a glowing beam and transform into code. Inspired by the awesome Evervault visuals ✨
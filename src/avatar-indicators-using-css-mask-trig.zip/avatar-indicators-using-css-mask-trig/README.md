# Avatar Indicators, using CSS Mask / Trig

A Pen created on CodePen.

Original URL: [https://codepen.io/simeydotme/pen/ogNWvMN](https://codepen.io/simeydotme/pen/ogNWvMN).

This is a demo to show off a clever way to position avatar status indicators using CSS masks and trigonometry. Play around with the angle, size, offset, and gap controls to see how the indicators stick to the edge of the avatar without needing specific coordinates. Plus, toggle between pixels and percentages to see how the indicators adapt.

Under the hood, this demo uses CSS variables to control the size, gap, offset, and angle of the status indicators. It calculates the position of the indicator using trigonometry, taking into account the avatar's center point, radius, and the desired angle. The --x and --y variables are calculated using the cos and sin functions to determine the exact coordinates for the indicator.

The avatar image is masked using a radial gradient, which creates a circular cutout that follows the shape of the avatar. The status indicator is then positioned absolutely using the calculated --x and --y coordinates, creating the illusion that it's stuck to the edge of the avatar.

The different status classes (online, idle, dnd) simply change the background color of the indicator, but you could easily customize them to display different icons or styles.
# Light & Dark Mode In Just 1 Line of CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/mikemai2awesome/pen/NPPPozJ](https://codepen.io/mikemai2awesome/pen/NPPPozJ).


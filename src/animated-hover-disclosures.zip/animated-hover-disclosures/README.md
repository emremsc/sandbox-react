# Animated Hover Disclosures

A Pen created on CodePen.

Original URL: [https://codepen.io/jh3y/pen/XJWNMOO](https://codepen.io/jh3y/pen/XJWNMOO).


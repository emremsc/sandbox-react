# Swipeable Card Stack (iMessage)

A Pen created on CodePen.

Original URL: [https://codepen.io/abjt14/pen/WNBVrNG](https://codepen.io/abjt14/pen/WNBVrNG).

